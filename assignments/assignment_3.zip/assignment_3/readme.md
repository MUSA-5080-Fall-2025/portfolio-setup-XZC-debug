# Assignment 3 — Midterm Project Data Access

Due to the large size of the dataset used in **Assignment 3 (Midterm Project)**, the data files cannot be uploaded directly to this GitHub repository.  
To ensure full reproducibility of the analysis, all datasets are stored securely on Google Drive.

## Data Access

You can access and download all project data from the following link:

[Google Drive — Assignment 3 Midterm Data](https://drive.google.com/drive/folders/1pNMYbC2iNilt7diqpEEgRjJfGgp1-TRq?usp=drive_link)



